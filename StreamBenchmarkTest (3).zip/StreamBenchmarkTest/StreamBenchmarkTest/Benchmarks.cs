﻿using BenchmarkDotNet;
using BenchmarkDotNet.Attributes;
using System;
using System.IO;
using System.Text;

namespace StreamBenchmarkTest
{
    [MemoryDiagnoser(true)]
    public class Benchmarks
    {

        [Benchmark(Baseline = true)]
        public void Readlines()
        {
            string filePath = "generated_text_file.txt";
            using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        // Process the line here
                        // Example: Console.WriteLine(line);
                    }
                }
            }
        }

        [Benchmark]
        public void ChunkingOrBuffered()
        {
            string filePath = "generated_text_file.txt";
            using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    StringBuilder lineBuilder = new StringBuilder();
                    char[] buffer = new char[4096]; // Set the buffer size as needed

                    while (!reader.EndOfStream)
                    {
                        int bytesRead = reader.Read(buffer, 0, buffer.Length);

                        for (int i = 0; i < bytesRead; i++)
                        {
                            char currentChar = buffer[i];

                            if (currentChar == '&')
                            {
                                // Process the line here
                                // Example: Console.WriteLine(lineBuilder.ToString());
                                lineBuilder.Clear(); // Reset the StringBuilder for the next line
                            }
                            else
                            {
                                lineBuilder.Append(currentChar);
                            }
                        }
                    }

                    // Process any remaining characters after the last newline (if needed)
                    if (lineBuilder.Length > 0)
                    {
                        // Process the last line (if any)
                        // Example: Console.WriteLine(lineBuilder.ToString());
                    }
                }
            }
        }
    }
}
